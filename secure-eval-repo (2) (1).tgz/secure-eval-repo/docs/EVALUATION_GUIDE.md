# Evaluation Guide

How to use this repository to score candidate SAST / SCA / license-compliance
tools (e.g., Coverity, Klocwork, Parasoft C/C++test, Polyspace, Checkmarx,
Semgrep, CodeQL, Snyk, Mend/WhiteSource, Black Duck, JFrog Xray, GitHub
Advanced Security, OWASP Dependency-Track).

## 1. Recommended evaluation workflow

1. Import this repository as-is into the candidate tool (no fixes, no
   suppressions). Do not "clean up" findings before scanning - the point is
   to measure raw detection capability.
2. Run each capability the tool advertises against the matching directory:
   - MISRA C++ / CERT C++ static analysis -> `cpp-embedded/`
   - Rust memory-safety / unsafe-code analysis -> `rust-embedded/`
   - Python SAST (CWE/OWASP class) -> `python-ml/`
   - SCA (dependency CVE + transitive resolution) -> all manifests: 
     `cpp-embedded/conanfile.txt` + `vcpkg.json`, `rust-embedded/Cargo.toml`,
     `python-ml/requirements.txt` + `pyproject.toml`,
     `sca-manifests/package.json` + `package-lock.json`,
     `sca-manifests/go-can-tooling/go.mod`
   - License compliance -> `sca-manifests/LICENSE_MATRIX.md` plus the
     embedded `LICENSE` files under `cpp-embedded/third_party/`
3. Diff the tool's findings against `docs/EXPECTED_FINDINGS.md`.
4. Score:
   - **Recall** = (injected issues found) / (total injected issues, see
     summary counts at the bottom of EXPECTED_FINDINGS.md)
   - **Precision** = (true positives) / (true positives + false positives)
   - **Rule-mapping fidelity** = did the tool cite the correct MISRA
     rule number / CERT rule ID / CWE / CVE, not just "a" finding at that
     line
   - **Transitive depth** = did the tool surface CVEs that exist only in
     third/fourth-level transitive dependencies (see
     `rust-embedded/DEPENDENCIES.md` graph and the nested
     `package-lock.json` entries: `qs` via `express`->`send`, `braces` via
     `webpack`->`micromatch`)
   - **Reachability analysis** (if the tool supports it) = does it
     distinguish the CLI-argument-tainted sinks in `cpp-embedded/src/main.cpp`
     and `rust-embedded/src/main.rs` from dead-code-only findings

## 2. Suggested baseline/open-source comparison commands

These are optional - useful for sanity-checking a commercial tool's
findings against a free baseline before scoring.

```bash
# C++ - clang-tidy using the provided MISRA/CERT-oriented config
cd cpp-embedded && cmake -B build -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
clang-tidy -p build src/*.cpp

# Rust - cargo-audit for RUSTSEC advisories, clippy for unsafe-code lint
cd rust-embedded && cargo audit
cargo clippy -- -W clippy::all

# Python - bandit for CWE-class SAST, pip-audit / safety for CVEs
cd python-ml && bandit -r src/
pip-audit -r requirements.txt

# npm - npm audit / osv-scanner
cd sca-manifests && npm audit --package-lock-only

# Go - govulncheck
cd sca-manifests/go-can-tooling && govulncheck ./...
```

## 3. Things to specifically watch for during evaluation

- **False confidence on the C-style-cast findings** in `type_conversions.cpp`
  - some tools only flag C-style casts on primitive types and miss the
  polymorphic downcast cases.
- **Cross-language taint tracking**: `rust-embedded/src/ffi_bindings.rs`
  forwards a CLI argument across the Rust/C++ FFI boundary into the exact
  `strcpy` overflow in `cpp-embedded/src/string_handling.cpp`'s
  `copySensorLabel`. Very few tools correlate findings across languages -
  worth explicitly testing whether the vendor's "cross-language" claim
  holds up here.
- **Deliberately weak build config**: `cpp-embedded/CMakeLists.txt` disables
  compiler warnings (`-w`) - confirm the tool's analysis is independent of
  compiler diagnostics and doesn't silently inherit the suppressed warning
  set.
- **License edge cases**: confirm the tool attributes the GPL-3.0 stub via
  its embedded `LICENSE` file (not just a manifest lookup), and correctly
  separates the proprietary notice from OSS attribution output.
- **Secrets detection overlap**: several files (`crypto_misuse.cpp`,
  `crypto.rs`, `secrets_handling.py`) contain hardcoded secrets tagged with
  `pragma: allowlist secret` comments - use these to check whether the
  tool's secret-scanning respects (or ignores, as appropriate) allowlist
  annotations, and whether it still flags them if it doesn't support that
  syntax.

## 4. Out of scope / do not build or deploy

This repository intentionally does not compile cleanly against modern,
patched dependency versions and is not intended to run as a service. Do
not deploy `python-ml/src/inference_server.py` or the Go diagnostic tool
outside an isolated evaluation sandbox.

