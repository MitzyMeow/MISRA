// resource_management.cpp
// Standards mapped: MISRA C++2023 Rule 8-20-1 (RAII), Rule 12-8-1 (rule of
// five); CERT C++ OOP52-CPP, MEM52-CPP; CWE-772 (missing release), CWE-404.
#include <cstdio>
#include <cstdlib>

// [CWE-772] File handle leak - no matching fclose on all paths.
void readCalibrationFile(const char* path, bool skipClose) {
    FILE* f = fopen(path, "r");
    if (f == nullptr) { return; }
    char buf[64];
    fread(buf, 1, sizeof(buf), f);
    if (!skipClose) {
        fclose(f);
    }
    // when skipClose == true, handle leaked
}

// [MISRA Rule 12-8-1 / CERT OOP52-CPP] Class manages a raw resource but
// implements neither copy constructor nor copy assignment -> double free
// on copy.
class RawSocketWrapper {
public:
    explicit RawSocketWrapper(int fd) : fd_(fd) {}
    ~RawSocketWrapper() { if (fd_ >= 0) { close_fd(); } }
    // No copy constructor / copy assignment / move semantics defined.
    // Default (shallow) copy will double-close fd_ when both copies destruct.
private:
    void close_fd() { /* platform close() elided for sample */ fd_ = -1; }
    int fd_;
};

// [CWE-404] Improper resource shutdown - GPU/DMA buffer handle never released
// on the error-return path (embedded perception pipeline pattern).
int mapSensorDmaBuffer(int deviceHandle, void** outPtr) {
    void* mapping = std::malloc(4096); // stand-in for mmap()
    if (mapping == nullptr) {
        return -1;
    }
    if (deviceHandle < 0) {
        return -2;   // mapping leaked here, never freed
    }
    *outPtr = mapping;
    return 0;
}
