// integer_overflow.cpp
// Standards mapped: MISRA C++2023 Rule 4-1-1 (wraparound), Rule 6-2-1;
// CERT C++ INT30-C, INT32-C analogs; CWE-190, CWE-191, CWE-680.
#include <cstdint>
#include <cstdlib>
#include <iostream>

// [CWE-190] Unsigned integer wraparound used to size a heap allocation.
void allocateFromUserSize(std::uint32_t requestedElements) {
    // requestedElements * sizeof(int) can wrap on 32-bit size_t embedded targets.
    std::size_t bytes = requestedElements * sizeof(int);  // CERT INT30-C
    int* buf = static_cast<int*>(std::malloc(bytes));      // CWE-680 alloc size overflow
    if (buf != nullptr) {
        buf[0] = 0;
        std::free(buf);
    }
}

// [CWE-191] Signed integer underflow in a countdown loop used for a
// watchdog / retry counter on the embedded ECU.
void retryCountdown(std::int8_t retries) {
    while (retries >= 0) {
        // If caller passes 0 and this decrements past INT8_MIN wraps to positive
        retries = static_cast<std::int8_t>(retries - 1);
        if (retries < -100) { break; } // guard added too late; UB already possible
    }
}

// [MISRA Rule 4-1-1] Arithmetic operations that may wrap silently in
// odometry accumulation (safety-relevant: distance-to-collision calc).
std::int32_t accumulateOdometryTicks(std::int32_t currentTicks, std::int32_t deltaTicks) {
    return currentTicks + deltaTicks;  // no overflow check before addition
}
