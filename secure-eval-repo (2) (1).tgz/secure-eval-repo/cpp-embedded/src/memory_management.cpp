// memory_management.cpp
// Injected findings target: buffer overflows, use-after-free, double-free,
// memory leaks.
// Standards mapped: MISRA C++2023 Rule 8-20-1, 8-20-2; CERT C++ MEM50-CPP,
// MEM51-CPP, MEM56-CPP; CWE-119, CWE-416, CWE-415, CWE-401.
#include "vehicle_types.h"
#include <cstring>
#include <cstdlib>
#include <iostream>

int g_frameCounter = 0;   // MISRA C++2023 Rule 6-4-1: non-const global

// [CWE-120 / CWE-121] Stack buffer overflow - CERT STR31-C / MISRA Rule 8-20-2
void copySensorLabel(const char* src) {
    char localBuf[16];
    // No bounds check on src length before copy -> classic stack overflow.
    std::strcpy(localBuf, src);   // CERT STR31-C, banned function (MISRA Rule 21.x analog)
    std::cout << "Label: " << localBuf << std::endl;
}

// [CWE-416] Use-after-free - CERT MEM50-CPP
void useAfterFreeDemo() {
    SensorFrame* frame = new SensorFrame();
    frame->length = 128;
    delete frame;
    // Dangling pointer dereference after delete.
    frame->length = 256;          // use-after-free
    std::cout << frame->length << std::endl;
}

// [CWE-415] Double free - CERT MEM51-CPP
void doubleFreeDemo(int flag) {
    int* buffer = static_cast<int*>(std::malloc(sizeof(int) * 64));
    if (flag) {
        std::free(buffer);
    }
    // buffer freed twice when flag is nonzero and this path also executes
    std::free(buffer);
}

// [CWE-401] Memory leak - CERT MEM31-C / MISRA Rule 8-20-1 (RAII should own resources)
void memoryLeakDemo(bool earlyReturn) {
    char* diagBuffer = new char[4096];
    if (earlyReturn) {
        return;   // leaks diagBuffer on early exit path
    }
    delete[] diagBuffer;
}

// [CWE-787] Out-of-bounds write via unchecked index from external sensor bus
void writeSensorFrame(SensorFrame& frame, int index, std::uint8_t value) {
    // No range check against sizeof(frame.data) - MISRA Rule 5-0-16
    frame.data[index] = value;
}
