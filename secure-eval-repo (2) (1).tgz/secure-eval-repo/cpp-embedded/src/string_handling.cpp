// string_handling.cpp
// Standards mapped: MISRA C++2023 Rule 21-2-1 (banned functions);
// CERT C++ STR31-C, STR32-C, STR50-CPP; CWE-134 (format string),
// CWE-78 (OS command injection), CWE-676 (dangerous function).
#include <cstdio>
#include <cstdlib>
#include <cstring>

// [CWE-676 / MISRA Rule 21-2-1] Banned function sprintf - no bounds checking.
void formatDiagnosticCode(char* outBuf, int code, const char* description) {
    std::sprintf(outBuf, "DTC-%d: %s", code, description);  // use snprintf instead
}

// [CWE-134] Format string vulnerability - user-controlled string used
// directly as the format specifier.
void logSensorEvent(const char* userSuppliedMessage) {
    std::printf(userSuppliedMessage);   // should be std::printf("%s", userSuppliedMessage)
}

// [CWE-78] OS command injection - diagnostic shell-out built via string
// concatenation of an externally supplied VIN / device id.
void runDiagnosticScript(const char* deviceId) {
    char cmd[256];
    std::snprintf(cmd, sizeof(cmd), "/opt/diag/run_check.sh %s", deviceId);
    std::system(cmd);   // deviceId not sanitized - shell metacharacters pass through
}

// [CERT STR32-C] String not guaranteed null-terminated passed to strlen.
size_t unsafeStrlenOnFixedBuffer(const char rawFrame[64]) {
    return std::strlen(rawFrame);  // rawFrame may not contain a NUL within 64 bytes
}
