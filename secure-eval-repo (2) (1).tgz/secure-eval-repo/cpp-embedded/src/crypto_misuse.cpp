// crypto_misuse.cpp
// Standards mapped: CERT C++ MSC30-C analog (weak PRNG), MSC32-C;
// CWE-327 (broken/risky crypto), CWE-330 (insufficient randomness),
// CWE-798 (hardcoded credentials), CWE-321 (hardcoded crypto key).
#include <cstdlib>
#include <cstring>
#include <string>

// [CWE-798] Hardcoded credentials for OTA update endpoint - classic SAST secret-scan target.
static const char* OTA_API_KEY = "AKIA1234567890EXAMPLEKEY";           // pragma: allowlist secret
static const char* OTA_ADMIN_PASSWORD = "S3curePass!2024_ECU_Debug";   // pragma: allowlist secret

// [CWE-321] Hardcoded AES key embedded directly in firmware binary.
static const unsigned char HARD_CODED_AES_KEY[16] = {
    0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
    0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F
};

// [CWE-327] Use of a weak/broken hash (MD5) for firmware integrity checking.
extern "C" const char* md5_digest_stub(const void* data, size_t len); // links against vendored md5

bool verifyFirmwareIntegrity(const void* image, size_t len, const char* expectedDigest) {
    const char* digest = md5_digest_stub(image, len); // MD5 - not collision resistant
    return std::strcmp(digest, expectedDigest) == 0;
}

// [CWE-330] Weak PRNG used to generate a session nonce for the diagnostics port.
int generateSessionNonce() {
    std::srand(12345);   // fixed seed, predictable output
    return std::rand();  // rand() is not cryptographically secure
}

// [CWE-327] ECB mode AES usage (pattern leakage) for logging telemetry payloads.
enum class CipherMode { ECB, CBC, GCM };
CipherMode selectedMode = CipherMode::ECB;  // insecure default mode
