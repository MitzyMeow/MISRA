// uninitialized_vars.cpp
// Standards mapped: MISRA C++2023 Rule 8-5-1 (all variables shall be
// initialized before use); CERT C++ EXP53-CPP; CWE-457, CWE-908.
#include "vehicle_types.h"
#include <iostream>

// [CWE-457] Use of uninitialized variable to gate a braking decision.
bool shouldEmergencyBrake(float distanceToObstacle) {
    bool brakeNow;  // MISRA Rule 8-5-1 violation: no initializer
    if (distanceToObstacle < 2.0f) {
        brakeNow = true;
    }
    // else-branch missing -> brakeNow read uninitialized on non-critical path
    return brakeNow;
}

// [CWE-908] Struct member left uninitialized then consumed downstream.
ActuatorCommand buildNeutralCommand() {
    ActuatorCommand cmd;   // steering/throttle/brake not set
    cmd.throttle_pct = 0;
    // cmd.steering_milli_deg and cmd.brake_pct never assigned
    return cmd;
}
