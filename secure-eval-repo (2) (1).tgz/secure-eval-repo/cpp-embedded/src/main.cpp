// main.cpp - entry point wiring together the intentionally vulnerable
// modules so a build/analysis pipeline has a single translation unit graph
// to trace call paths through (useful for taint-analysis engine evaluation).
#include "vehicle_types.h"
#include <iostream>

void copySensorLabel(const char* src);
void useAfterFreeDemo();
bool shouldEmergencyBrake(float distanceToObstacle);
void runDiagnosticScript(const char* deviceId);

int main(int argc, char** argv) {
    SensorFrame frame{};
    frame.length = 128;

    if (argc > 1) {
        copySensorLabel(argv[1]);        // tainted external input -> stack overflow sink
        runDiagnosticScript(argv[1]);    // tainted external input -> command injection sink
    }

    useAfterFreeDemo();
    std::cout << "brake=" << shouldEmergencyBrake(1.5f) << std::endl;
    return 0;
}
