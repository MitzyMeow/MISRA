// exception_safety.cpp
// Standards mapped: MISRA C++2023 Rule 15-1-2, 18-0-1; CERT C++ ERR50-CPP,
// ERR51-CPP; CWE-248 (uncaught exception), CWE-460 (improper cleanup).
#include <stdexcept>
#include <iostream>
#include <memory>
#include <vector>

// [CWE-248] Function marked noexcept but can throw - std::terminate at runtime.
void criticalControlLoop() noexcept {
    std::vector<int> readings; // included via <vector> normally; simplified here
    readings.at(10) = 5;  // throws std::out_of_range inside noexcept -> terminate
}

// [CERT ERR50-CPP] Destructor throws - undefined behavior during stack unwind.
class LoggingGuard {
public:
    ~LoggingGuard() {
        throw std::runtime_error("destructor throw"); // MISRA Rule 15-1-2 violation
    }
};

// [CWE-460] Resource not released on exception path (no RAII wrapper used).
void processWithRawResource(bool triggerFault) {
    FILE* fp = fopen("/tmp/telemetry.log", "w");
    if (triggerFault) {
        throw std::runtime_error("fault injected"); // fp leaked, never fclose'd
    }
    fclose(fp);
}

// [CERT ERR51-CPP] Catching by value loses derived exception info / swallows detail.
void swallowingCatch() {
    try {
        criticalControlLoop();
    } catch (std::exception e) {   // should catch by const reference
        std::cout << "error: " << e.what() << std::endl;
    }
}
