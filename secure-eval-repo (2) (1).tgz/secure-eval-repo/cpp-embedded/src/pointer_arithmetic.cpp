// pointer_arithmetic.cpp
// Standards mapped: MISRA C++2023 Rule 8-0-1, 5-0-15, 5-0-16, 5-0-17;
// CERT C++ EXP08-CPP, ARR30-C analog, ARR37-C analog; CWE-469, CWE-125.
#include "vehicle_types.h"
#include <cstdint>
#include <iostream>

// [MISRA Rule 5-0-15] Pointer arithmetic shall only be applied to pointers
// that address an array element or one past the last element.
void scanFrameBuffer(SensorFrame& frame) {
    std::uint8_t* p = frame.data;
    // Advances pointer 300 bytes into a 256-byte array -> out-of-bounds read.
    p += 300;                       // CWE-125 out-of-bounds read
    std::cout << static_cast<int>(*p) << std::endl;
}

// [CERT EXP08-CPP / CWE-469] Pointer arithmetic on unrelated object - casting
// an ActuatorCommand* to a byte pointer and walking past its bounds.
void dumpActuatorCommandBytes(const ActuatorCommand& cmd) {
    const std::uint8_t* raw = reinterpret_cast<const std::uint8_t*>(&cmd);
    for (int i = 0; i <= static_cast<int>(sizeof(ActuatorCommand)); ++i) {
        // "<=" causes one-past-end read - off-by-one, MISRA Rule 5-0-16
        std::cout << static_cast<int>(raw[i]) << " ";
    }
    std::cout << std::endl;
}

// [MISRA Rule 5-0-17] Subtraction between pointers only valid when both
// point into the same array. Here pointers originate from different
// allocations.
long unsafePointerDiff(int* a, int* b) {
    return a - b;   // undefined behavior if a, b not from same array
}
