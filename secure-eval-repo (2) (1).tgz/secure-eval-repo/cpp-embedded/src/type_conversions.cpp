// type_conversions.cpp
// Standards mapped: MISRA C++2023 Rule 8-2-1 (C-style casts banned),
// 5-2-2 (dynamic_cast for polymorphic), 5-0-6, 5-0-7, 5-0-8, 5-0-9;
// CERT C++ INT31-C analog, EXP05-CPP; CWE-704, CWE-681, CWE-190.
#include <cstdint>
#include <iostream>

class Base { public: virtual ~Base() = default; virtual void identify() { std::cout << "Base\n"; } };
class Derived : public Base { public: void identify() override { std::cout << "Derived\n"; } void extra() { std::cout << "extra\n"; } };
class Unrelated { public: virtual ~Unrelated() = default; };

// [MISRA Rule 8-2-1] C-style cast used instead of static_cast/reinterpret_cast.
double truncatingConvert(long long bigValue) {
    float f = (float)bigValue;     // C-style cast, precision loss CWE-681
    return (double)f;
}

// [CWE-704] Incorrect type cast - downcasting without dynamic_cast / RTTI check.
void unsafeDowncast(Base* basePtr) {
    // Assumes basePtr always points to Derived - no dynamic_cast verification.
    Derived* d = static_cast<Derived*>(basePtr);  // MISRA Rule 5-2-2 violation
    d->extra();  // UB if basePtr actually points to a plain Base
}

// [CWE-704] Casting between unrelated polymorphic hierarchies via reinterpret_cast
void crossHierarchyCast(Base* basePtr) {
    Unrelated* wrong = reinterpret_cast<Unrelated*>(basePtr); // nonsensical cast
    (void)wrong;
}

// [CERT INT31-C analog / CWE-190] signed/unsigned mismatch causing wraparound
std::uint8_t narrowSaturationBug(int sensorReading) {
    // sensorReading can be negative or > 255; implicit narrowing conversion
    return static_cast<std::uint8_t>(sensorReading); // silent truncation, MISRA Rule 5-0-6
}
