// control_flow_misra.cpp
// Standards mapped: MISRA C++2023 Rule 0-1-1 (no unreachable code), Rule
// 0-1-9 (no dead code), Rule 6-3-1 (goto prohibited), Rule 6-4-5 (switch
// fallthrough); CERT C++ MSC12-C analog; CWE-561 (dead code), CWE-484
// (omitted break in switch).
#include <iostream>

// [MISRA Rule 0-1-1 / CWE-561] Unreachable code after an unconditional
// return - common after refactors, exactly what dead-code checkers exist
// to catch.
int computeChecksumMode(int flags) {
    return flags & 0xFF;
    flags = 0;              // unreachable - dead code below a return
    std::cout << flags;     // also unreachable
    return -1;
}

// [MISRA Rule 6-3-1] goto used to implement cleanup/retry logic instead of
// structured control flow - common in ported C embedded code.
int retryWithGoto(int attempts) {
    int result = -1;
retry:
    if (attempts <= 0) {
        return result;
    }
    result = attempts;
    attempts--;
    if (result % 2 == 0) {
        goto retry;   // MISRA-banned control transfer
    }
    return result;
}

// [MISRA Rule 6-4-5 / CWE-484] Missing break causes unintended fallthrough
// between actuator command modes - safety relevant (throttle mode falling
// through into brake mode).
void applyActuatorMode(int mode, int& throttlePct, int& brakePct) {
    switch (mode) {
        case 0:
            throttlePct = 0;
            // missing break - falls through into case 1
        case 1:
            brakePct = 100;   // unintentionally always applied when mode==0 too
            break;
        default:
            break;
    }
}
