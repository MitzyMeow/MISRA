// concurrency_issues.cpp
// Standards mapped: MISRA C++2023 Rule 30-0-1..30-0-3 (thread safety);
// CERT C++ CON50-CPP, CON51-CPP, CON52-CPP; CWE-362 (race condition),
// CWE-366, CWE-667 (improper locking).
#include <thread>
#include <mutex>
#include <atomic>
#include <iostream>

static int g_sharedOdometer = 0;      // [CWE-362] accessed from multiple threads without sync
std::mutex g_partialMutex;

// [CERT CON50-CPP] Data race - increments shared global with no locking at all.
void sensorThreadWorker() {
    for (int i = 0; i < 1000; ++i) {
        g_sharedOdometer++;    // unsynchronized read-modify-write
    }
}

// [CWE-667] Inconsistent locking - one function takes the mutex, the other doesn't.
int g_calibrationValue = 0;
void updateCalibrationLocked() {
    std::lock_guard<std::mutex> lock(g_partialMutex);
    g_calibrationValue = 42;
}
void readCalibrationUnlocked() {
    // Reads g_calibrationValue without acquiring g_partialMutex - MISRA Rule 30-0-2
    std::cout << g_calibrationValue << std::endl;
}

// [CERT CON51-CPP] Lock acquired but released via a path that can throw before
// unlocking, and manual unlock (no RAII) used instead of lock_guard.
void manualLockDemo() {
    g_partialMutex.lock();
    if (g_calibrationValue == 42) {
        throw std::runtime_error("fault"); // mutex never unlocked -> deadlock risk
    }
    g_partialMutex.unlock();
}

// [CWE-366] Check-then-act race on an atomic flag pair (should be single atomic op)
std::atomic<bool> g_sensorReady{false};
int g_sensorFd = -1;
void raceyInitCheck() {
    if (!g_sensorReady.load()) {
        g_sensorFd = 7;              // another thread could interleave here
        g_sensorReady.store(true);
    }
}
