// safety_critical_patterns.cpp
// ISO 26262-6 discourages these patterns for ASIL C/D software (Table 1:
// recommended design/coding guidelines) because they undermine
// determinism, bounded stack usage, and verifiability. Standards mapped:
// MISRA C++2023 Rule 8-2-3 (no recursion in some profiles), Rule 6-5-1
// (loop shall have well-defined termination); CWE-674 (uncontrolled
// recursion), CWE-835 (infinite loop), CWE-617 (safety check removed by
// NDEBUG).
#include <cassert>
#include <cstdint>

// [CWE-674] Unbounded recursion - stack depth is data-dependent and
// unverifiable at compile time; a corrupted/adversarial depth value can
// exhaust the ECU's bounded stack (no tail-call guarantee in C++).
std::int32_t recursiveChecksum(const std::uint8_t* data, std::int32_t length) {
    if (length <= 0) {
        return 0;
    }
    // No depth limit / iterative rewrite - recursion depth == length.
    return data[length - 1] + recursiveChecksum(data, length - 1);
}

// [CWE-835 / MISRA Rule 6-5-1] Loop with no statically-verifiable
// termination condition - the exit depends on an externally-mutated
// volatile flag that a static analyzer (and a safety case reviewer) can't
// prove ever changes.
volatile bool g_shutdownRequested = false;
void controlLoopUntilShutdown() {
    while (true) {              // no bound, no timeout - relies entirely on
        if (g_shutdownRequested) {  // an external actor setting this flag
            break;
        }
        // ... perform control cycle ...
    }
}

// [CWE-617 / ISO 26262 relevant] Safety-critical bounds check implemented
// as assert() - assert() compiles to a no-op when NDEBUG is defined
// (typical for optimized release/production embedded builds), silently
// removing the safety check from the shipped binary.
void writeActuatorRegister(std::uint8_t* registers, int index, std::uint8_t value) {
    assert(index >= 0 && index < 16);  // vanishes under -DNDEBUG in release builds
    registers[index] = value;           // becomes an unchecked OOB write in release
}
