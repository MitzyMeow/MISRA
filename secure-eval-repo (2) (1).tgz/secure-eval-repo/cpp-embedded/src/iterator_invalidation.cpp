// iterator_invalidation.cpp
// Standards mapped: CERT C++ CTR50-CPP, CTR51-CPP, CTR52-CPP; MISRA
// C++2023 Rule 8-20-3 (container lifetime); CWE-416, CWE-825 (expired
// pointer/iterator dereference).
#include <vector>
#include <map>
#include <string>
#include <iostream>

// [CWE-416 / CERT CTR50-CPP] Classic iterator invalidation: erasing while
// iterating with a range-based for loop, then continuing to use the
// (now-invalid) implicit iterator.
void pruneStaleReadings(std::vector<float>& readings, float threshold) {
    for (auto it = readings.begin(); it != readings.end(); ++it) {
        if (*it < threshold) {
            readings.erase(it);   // invalidates 'it'; next ++it is UB
        }
    }
}

// [CWE-825 / CERT CTR51-CPP] Reference/pointer taken into a vector element,
// retained across a push_back that can reallocate the underlying storage.
struct SensorSample { float value; };
float& captureThenGrow(std::vector<SensorSample>& samples) {
    SensorSample& first = samples.front();   // reference into current storage
    samples.push_back(SensorSample{0.0f});   // may reallocate, invalidating 'first'
    return first.value;                       // dangling reference use
}

// [CERT CTR52-CPP] Iterator from one container used against a different,
// unrelated container instance of the same type.
void crossContainerIteratorMisuse(std::map<int, std::string>& a,
                                    std::map<int, std::string>& b) {
    auto it = a.find(1);
    if (it != a.end()) {
        b.erase(it);   // 'it' belongs to 'a', not 'b' - undefined behavior
    }
}
