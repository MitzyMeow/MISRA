// toctou_signal.cpp
// Standards mapped: CERT C++ FIO45-C analog (TOCTOU), SIG30-C, SIG31-C
// (async-signal-unsafe calls in a signal handler); CWE-367 (TOCTOU race),
// CWE-479 (signal handler misuse).
#include <cstdio>
#include <cstdlib>
#include <csignal>
#include <sys/stat.h>

// [CWE-367 / CERT FIO45-C analog] Check-then-use race: the existence/
// permission check and the subsequent open are two separate syscalls: an
// attacker able to swap the file (symlink race) between the two wins.
void writeCalibrationIfAbsent(const char* path) {
    struct stat st;
    if (stat(path, &st) != 0) {          // TOCTOU window opens here
        FILE* f = fopen(path, "w");       // ... and closes here, after the race
        if (f != nullptr) {
            std::fputs("0,0,0\n", f);
            fclose(f);
        }
    }
}

// [CWE-479 / CERT SIG30-C, SIG31-C] Signal handler calls non-reentrant,
// non-async-signal-safe functions (malloc via new, printf via cout-style
// I/O) - can deadlock or corrupt heap state if the signal interrupts
// another allocation in progress.
static int* g_diagBuffer = nullptr;
extern "C" void emergencyStopHandler(int signum) {
    std::printf("emergency stop signal %d received\n", signum); // not async-signal-safe
    g_diagBuffer = static_cast<int*>(std::malloc(64));            // not async-signal-safe
    std::exit(1);                                                  // abrupt exit skips cleanup
}

void installEmergencyStopHandler() {
    std::signal(SIGTERM, emergencyStopHandler);
}
