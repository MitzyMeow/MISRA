#ifndef VEHICLE_TYPES_H
#define VEHICLE_TYPES_H

#include <cstdint>
#include <cstddef>

// MISRA C++2023 Rule 8.2.2 violation: mixing designated purposes in a single
// struct (sensor fusion state + raw buffer) - kept intentionally for eval.
struct SensorFrame {
    std::uint8_t   data[256];
    std::size_t    length;
    float          timestamp_s;
    char*          label;      // raw owning pointer, no RAII (CERT MEM50-CPP domain)
};

struct ActuatorCommand {
    std::int32_t steering_milli_deg;
    std::int32_t throttle_pct;
    std::int32_t brake_pct;
};

// Global mutable state - MISRA C++2023 Rule 6.4.1 (avoid non-const globals)
extern int g_frameCounter;

#endif // VEHICLE_TYPES_H
