# Intentionally Injected Strong-Copyleft Component

`gpl_component_stub/` vendors a minimal stand-in for a GPL-3.0-licensed
signal-processing helper (modeled on a real-world pattern: teams pulling in
a small GPL'd DSP snippet from a forum/StackOverflow answer without
realizing the licensing implication for a proprietary embedded product).

This is here purely to test whether the SCA/license tool under evaluation
flags a strong-copyleft license mixed into an otherwise permissively
licensed C++ codebase, and whether it can attribute the license correctly
from the embedded `LICENSE` file rather than requiring a manifest entry.
