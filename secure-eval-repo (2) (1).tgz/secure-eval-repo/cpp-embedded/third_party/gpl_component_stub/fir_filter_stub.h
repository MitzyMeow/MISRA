// fir_filter_stub.h - GPL-3.0 licensed FIR filter helper (stub).
// SPDX-License-Identifier: GPL-3.0-only
#ifndef FIR_FILTER_STUB_H
#define FIR_FILTER_STUB_H
double apply_fir_filter_stub(const double* samples, int count);
#endif
