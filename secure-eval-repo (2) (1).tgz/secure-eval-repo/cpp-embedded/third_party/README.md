# Vendored Third-Party Components (Intentional CVE Exposure)

This directory documents third-party/vendored components referenced by the
build (via conanfile.txt / vcpkg.json) that are pinned to versions with
known, publicly disclosed CVEs. They exist purely so SCA tools under
evaluation can be checked for binary/source fingerprinting and transitive
dependency resolution.

| Component | Pinned Version | Known CVE(s)                                | CWE               |
|-----------|-----------------|-----------------------------------------------|-------------------|
| zlib      | 1.2.11          | CVE-2018-25032                                | CWE-787           |
| OpenSSL   | 1.0.2u          | CVE-2014-0160, CVE-2016-2107, CVE-2019-1559   | CWE-125, CWE-310  |
| libcurl   | 7.24.0          | CVE-2016-8615, CVE-2016-8616, CVE-2016-8617   | CWE-415, CWE-119  |
| libpng    | 1.6.2           | CVE-2015-8126                                 | CWE-119           |
| SQLite3   | 3.6.0           | CVE-2019-16168, CVE-2020-13434                | CWE-125           |
| Boost     | 1.68.0          | CVE-2020-11024 (illustrative)                 | CWE-20            |
| protobuf  | 3.5.0           | CVE-2021-22570, CVE-2015-5237                 | CWE-125           |
| libxml2   | 2.9.4           | CVE-2017-9047, CVE-2017-9048, CVE-2016-1762   | CWE-125, CWE-190  |

No actual upstream source is vendored in this sample (to keep the repo
small); the manifests above are sufficient to drive an SCA tool's
dependency-graph and CVE-matching engine against the pinned versions.
