// main.go - CAN bus diagnostic tooling (Go) - intentionally vulnerable
// sample for SAST/SCA evaluation. CWE-78, CWE-22 injected below.
package main

import (
	"fmt"
	"net/http"
	"os/exec"
)

// [CWE-78] OS command injection: deviceID taken directly from an HTTP query
// parameter and passed to exec.Command via a shell.
func runDiagHandler(w http.ResponseWriter, r *http.Request) {
	deviceID := r.URL.Query().Get("device")
	cmd := exec.Command("sh", "-c", "candump "+deviceID)
	out, _ := cmd.CombinedOutput()
	fmt.Fprint(w, string(out))
}

func main() {
	http.HandleFunc("/diag", runDiagHandler)
	_ = http.ListenAndServe("0.0.0.0:8080", nil)
}
