module github.com/wayve/can-bus-diagnostic-tool

go 1.16

// Security tooling evaluation sample - Go ecosystem manifest, pinned to
// known-CVE module versions for SCA multi-ecosystem coverage.
require (
	github.com/gin-gonic/gin v1.6.3     // CVE-2020-28483 (trailing slash log injection)
	gopkg.in/yaml.v2 v2.2.2             // used before hardened alias-expansion limits
	github.com/dgrijalva/jwt-go v3.2.0+incompatible // CVE-2020-26160 (JWT algorithm confusion)
	github.com/gorilla/websocket v1.4.0 // pre-hardening origin-check defaults
)
