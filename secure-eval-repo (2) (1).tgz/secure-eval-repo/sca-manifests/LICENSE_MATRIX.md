# License Compliance Evaluation Matrix

This document catalogs the license obligations introduced across every
ecosystem in this sample repo, so a license-compliance engine (FOSSA,
Mend/WhiteSource, Black Duck, ScanCode, `cargo-deny`, `pip-licenses`,
`license-checker`) can be evaluated for detection accuracy, including
copyleft escalation (GPL/AGPL) buried in transitive dependencies and a
proprietary/no-license package.

## Direct license mix by ecosystem

| Ecosystem | Package            | Version   | License        | Compliance Note                                  |
|-----------|---------------------|-----------|-----------------|---------------------------------------------------|
| C++ (Conan/vcpkg) | zlib        | 1.2.11    | Zlib            | Permissive                                         |
| C++       | openssl              | 1.0.2u    | OpenSSL/SSLeay  | Permissive w/ attribution clause                   |
| C++       | libcurl              | 7.24.0    | MIT/curl        | Permissive                                         |
| C++       | libpng               | 1.6.2     | libpng license  | Permissive                                         |
| C++       | sqlite3              | 3.6.0     | Public Domain   | No restriction                                     |
| C++       | boost                | 1.68.0    | BSL-1.0         | Permissive                                         |
| C++       | protobuf             | 3.5.0     | BSD-3-Clause    | Permissive                                         |
| C++       | libxml2              | 2.9.4     | MIT              | Permissive                                         |
| Rust      | time                 | 0.2.22    | MIT / Apache-2.0| Dual license, permissive                           |
| Rust      | openssl (bindings)   | 0.10.29   | Apache-2.0       | Permissive                                         |
| Rust      | serde_yaml           | 0.8.13    | MIT / Apache-2.0| Permissive                                         |
| Python    | PyYAML               | 5.3.1     | MIT              | Permissive                                         |
| Python    | Django               | 2.2.0     | BSD-3-Clause     | Permissive                                         |
| Python    | paramiko             | 2.4.1     | **LGPL-2.1**     | **Copyleft (weak) - dynamic linking obligations**  |
| Python    | lxml                 | 4.2.5     | BSD-3-Clause     | Permissive                                         |
| npm       | handlebars           | 4.1.2     | MIT              | Permissive                                         |
| npm       | uglify-js (transitive)| 3.4.9    | BSD-2-Clause     | Permissive, transitive-only detection test         |
| Go        | gin-gonic/gin        | 1.6.3     | MIT              | Permissive                                         |
| Go        | dgrijalva/jwt-go     | 3.2.0     | MIT              | Permissive, also has security advisory (see below) |

## Deliberately injected copyleft / restrictive licenses

| Component                       | Location                              | License     | Why it matters                                                             |
|----------------------------------|----------------------------------------|-------------|------------------------------------------------------------------------------|
| `paramiko` 2.4.1                 | python-ml/requirements.txt             | **LGPL-2.1**| Weak copyleft - flag for legal review if statically linked into a closed product |
| GPL-flagged internal fork stub   | cpp-embedded/third_party/README.md notes Boost/SQLite as permissive baseline; see `third_party/GPL_COMPONENT_NOTICE.md` | **GPL-3.0** | Strong copyleft component intentionally added to test "network/distribution trigger" detection |
| Proprietary EULA snippet         | `sca-manifests/PROPRIETARY_NOTICE.txt` | Proprietary / no redistribution | Tests detection of unlicensed / all-rights-reserved code mixed into an OSS-heavy tree |

## Expected tool behavior

A capable license-compliance scanner run against this repo should surface:
1. At least one **strong copyleft (GPL-3.0)** component requiring escalation.
2. At least one **weak copyleft (LGPL-2.1)** component (paramiko) with a linking-based obligation.
3. A **proprietary/no-license** file that should be excluded from any OSS attribution notice but flagged for internal legal review.
4. Transitive-only license detection (e.g., `uglify-js` pulled in solely via `handlebars`, not declared as a direct dependency).
