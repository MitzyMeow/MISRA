# Security Tooling Evaluation Sample Repository

A deliberately vulnerable, multi-language, multi-ecosystem sample repo for
evaluating Static Application Security Testing (SAST) and Software
Composition Analysis (SCA) tooling, modeled on Wayve's embedded (C++/Rust)
+ ML tooling (Python) stack.

**This code is intentionally insecure. Do not build, deploy, or reuse any
part of it outside an isolated evaluation environment.**

## Why this exists

Picking a security tool from marketing claims alone is unreliable. This
repo gives the team a fixed "answer key" (see `docs/EXPECTED_FINDINGS.md`)
listing every intentionally injected vulnerability, mapped to its MISRA/
CERT rule, CWE, or CVE - so each candidate tool can be run against the
same code and scored objectively on recall (did it find the issue),
precision (how much noise came with it), and rule-mapping accuracy.

## Structure

```
cpp-embedded/     C++17 embedded/perception code - MISRA C++2023 & CERT C++
                  violations (memory safety, pointer/integer errors,
                  exception safety, RAII/resource leaks, concurrency,
                  crypto misuse, string handling, iterator invalidation,
                  unreachable code/goto/fallthrough, ISO 26262-relevant
                  patterns like unbounded recursion/non-deterministic loops/
                  NDEBUG-stripped safety asserts, TOCTOU races, unsafe
                  signal handlers) + Conan/vcpkg manifests pinned to
                  CVE-affected library versions. Includes a vendored
                  GPL-3.0 stub component for license testing.

rust-embedded/    Rust embedded code - unsafe-code memory issues, panic/
                  abort-on-fault patterns, unsafe C++ FFI boundary, weak
                  crypto/secrets, data races, bounds-check bypass
                  (get_unchecked), lossy numeric casts, unsound unsafe
                  impl Send/Sync, and an Rc/RefCell reference-cycle leak
                  in otherwise-safe code - plus Cargo.toml pinned to
                  crates with known RUSTSEC advisories (direct + transitive,
                  see DEPENDENCIES.md).

python-ml/        Python ML/model-development code - insecure
                  deserialization (pickle/torch.load/YAML), SSRF, SQLi,
                  command injection, hardcoded secrets, weak crypto, SSTI
                  (Jinja2), XXE, ReDoS, zip-slip archive extraction, and
                  JWT signature-verification bypass/algorithm-confusion -
                  plus requirements.txt/pyproject.toml pinned to
                  CVE-affected package versions.

sca-manifests/    Additional ecosystem manifests (npm, Go) to exercise
                  multi-ecosystem SCA + transitive dependency resolution,
                  plus LICENSE_MATRIX.md, injected GPL-3.0/LGPL-2.1/
                  proprietary license cases, and supply-chain integrity
                  fixtures (known malicious typosquat packages, deprecated/
                  unmaintained dependencies).

docs/             EXPECTED_FINDINGS.md (the answer key: every injected
                  issue mapped to MISRA rule / CERT rule / CWE / CVE) and
                  EVALUATION_GUIDE.md (how to run the evaluation and score
                  results).
```

## Quick start

1. Read `docs/EVALUATION_GUIDE.md` first.
2. Point each candidate tool at the relevant subdirectory (or the whole
   repo, if the tool claims multi-language support).
3. Diff findings against `docs/EXPECTED_FINDINGS.md`.
4. Record recall/precision/rule-mapping fidelity per tool in your own
   comparison sheet.

## Coverage summary

- **Languages**: C++17, Rust, Python 3.9, plus Go and JavaScript/npm
  manifests for SCA ecosystem breadth.
- **Standards targeted**: MISRA C++:2023, CERT C++ Secure Coding Standard,
  CWE Top 25 classes, OWASP-style web/ML service issues, and coding
  patterns called out by ISO 26262-6 (unbounded recursion, non-
  deterministic loops, NDEBUG-stripped safety checks, dead/unreachable
  code) for the C++ embedded stack. Note the accuracy caveat on MISRA
  rule numbers at the top of `docs/EXPECTED_FINDINGS.md`.
- **~90 intentionally injected code-level findings** across C++/Rust/Python
  (see counts at the bottom of `docs/EXPECTED_FINDINGS.md`).
- **29+ dependency CVEs** across 5 package ecosystems, including
  transitive-only cases (npm `qs`/`braces`, Rust `yaml-rust`).
- **4 supply-chain integrity fixtures**: known malicious typosquat
  packages (`colourama`, `crossenv`) and deprecated/unmaintained
  dependencies (`pycrypto`, `request`), for tools that score package
  reputation/maintenance signals, not just CVEs.
- **License compliance**: permissive (MIT/BSD/Apache/Zlib/BSL/Public
  Domain), weak copyleft (LGPL-2.1), strong copyleft (GPL-3.0), and
  proprietary/no-license content all represented.
